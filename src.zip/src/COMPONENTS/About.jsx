import React from 'react';
import './About.css';
const AboutUs = () => {
  return (
    <div className="about-us-container">
      <h1>About Us</h1>
      <p>Welcome to our Inventory Management App! Our mission is to provide efficient and reliable inventory solutions to help businesses streamline their operations.</p>
      
      <h2>Our Story</h2>
      <p>Founded in 2021, our company has been dedicated to developing top-notch inventory management software. With a team of experienced developers and industry experts, we strive to deliver the best user experience and functionality.</p>
      
      <h2>Our Team</h2>
      <p>We are a group of passionate individuals who are committed to making inventory management easier for everyone. Our team consists of software engineers, designers, and customer support specialists who work together to ensure our product meets your needs.</p>
      
      <h2>Contact Us</h2>
      <p>If you have any questions or feedback, feel free to reach out to us at <a href="mailto:support@inventoryapp.com">support@inventoryapp.com</a>.</p>
    </div>
  );
}

export default AboutUs;
