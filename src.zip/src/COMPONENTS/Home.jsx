// src/components/HomePage.js
import React from 'react';
import './Home.css';

const HomePage = () => {
  return (
    <div className="homepage-container">
      <div className="header">
        <h1>Invenzen</h1>
      </div>
      <div className="content">
        <div className="text-section">
          <h1>Manage less.<br />Sell more.<br />Connect everything.</h1>
          <p>
            Product businesses need more than inventory management to grow. <strong>Connected Inventory Performance</strong> automatically creates a real-time picture of everything you make and sell, everywhere you need it – across systems, channels, marketplaces, and regions.
          </p>
        </div>
        <div className="image-section">
        </div>
      </div>
    </div>
  );
}

export default HomePage;
